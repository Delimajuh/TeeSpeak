<?php 
// Cria as variaveis de ambiente
$host = "localhost";
$usuario = "root";
$senha = "ienh";
$base = "teespeak";

// Cria uma conexão no banco de dados
$conexao = mysqli_connect($host, $usuario, $senha, $base); 
?>